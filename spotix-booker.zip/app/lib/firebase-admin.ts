import admin from "firebase-admin"

if (!admin.apps.length) {
  const serviceAccount = {
    projectId: process.env.FIREBASE_PROJECT_ID,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
  }

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount as any),
  })
}

export const adminDb = admin.firestore()
export const adminAuth = admin.auth()
export const FieldValue = admin.firestore.FieldValue