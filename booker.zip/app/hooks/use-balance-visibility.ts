"use client"

import { useState, useEffect, useCallback } from "react"

const STORAGE_KEY = "spotix_balance_visible"

/**
 * Shared hook for balance visibility toggle.
 * Persists to localStorage so the preference survives navigation.
 */
export function useBalanceVisibility() {
  const [visible, setVisible] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored !== null) setVisible(stored === "true")
    } catch {}
  }, [])

  const toggle = useCallback(() => {
    setVisible((prev) => {
      const next = !prev
      try { localStorage.setItem(STORAGE_KEY, String(next)) } catch {}
      return next
    })
  }, [])

  return { visible: mounted ? visible : true, toggle, mounted }
}
